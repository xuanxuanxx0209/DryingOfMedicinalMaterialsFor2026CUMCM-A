Main file: example.tex
Compiler: XeLaTeX
This archive contains the current paper and all 16 referenced PDF figures.
